// Nur diese Datei musst du ändern: Texte rein, rendern, fertig.
export const script = {
  hook: 'Das wusstest du über Schlaf nicht!',
  points: [
    'Dein Gehirn räumt nachts auf',
    'Weniger als 6 Stunden schadet dem Gedächtnis',
    'Kein Handy 30 Minuten vor dem Schlafen hilft',
  ],
  outro: 'Folge für mehr Tipps!',
  // Farbverläufe pro Szene (werden der Reihe nach wiederholt)
  colors: [
    ['#ff0080', '#7928ca'],
    ['#00c6ff', '#0072ff'],
    ['#f7971e', '#ff3d00'],
    ['#11998e', '#38ef7d'],
  ] as [string, string][],
};
