import React from 'react';
import {Composition} from 'remotion';
import {TikTokVideo, SCENE} from './Video';
import {script} from './script';

const sceneCount = script.points.length + 2; // Hook + Punkte + Outro

export const Root: React.FC = () => (
  <Composition
    id="TikTok"
    component={TikTokVideo}
    durationInFrames={sceneCount * SCENE}
    fps={30}
    width={1080}
    height={1920}
  />
);
