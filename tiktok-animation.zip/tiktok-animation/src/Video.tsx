import React from 'react';
import {
  AbsoluteFill,
  Sequence,
  interpolate,
  spring,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {script} from './script';

export const SCENE = 90; // 3 Sekunden pro Szene bei 30 fps

const Scene: React.FC<{text: string; bg: [string, string]; label?: string}> = ({
  text,
  bg,
  label,
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const words = text.split(' ');
  const angle = 160 + frame * 0.6;
  const fadeOut = interpolate(frame, [SCENE - 8, SCENE], [1, 0], {
    extrapolateLeft: 'clamp',
  });

  return (
    <AbsoluteFill
      style={{
        background: `linear-gradient(${angle}deg, ${bg[0]}, ${bg[1]})`,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 80,
        opacity: fadeOut,
        fontFamily: 'Arial, Helvetica, sans-serif',
      }}
    >
      {label && (
        <div
          style={{
            position: 'absolute',
            top: 220,
            fontSize: 60,
            fontWeight: 800,
            color: 'rgba(255,255,255,0.8)',
            letterSpacing: 4,
          }}
        >
          {label}
        </div>
      )}
      <div
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'center',
          gap: '10px 28px',
        }}
      >
        {words.map((w, i) => {
          const s = spring({frame: frame - i * 5, fps, config: {damping: 12}});
          return (
            <span
              key={i}
              style={{
                fontSize: 110,
                fontWeight: 900,
                color: '#fff',
                opacity: s,
                transform: `translateY(${(1 - s) * 60}px) scale(${0.6 + 0.4 * s})`,
                textShadow: '0 6px 30px rgba(0,0,0,0.35)',
              }}
            >
              {w}
            </span>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};

export const TikTokVideo: React.FC = () => {
  const frame = useCurrentFrame();
  const scenes = [
    {text: script.hook},
    ...script.points.map((p, i) => ({
      text: p,
      label: `${i + 1} / ${script.points.length}`,
    })),
    {text: script.outro},
  ];
  const total = scenes.length * SCENE;
  const progress = interpolate(frame, [0, total], [0, 100]);

  return (
    <AbsoluteFill style={{backgroundColor: '#000'}}>
      {scenes.map((s, i) => (
        <Sequence key={i} from={i * SCENE} durationInFrames={SCENE}>
          <Scene
            text={s.text}
            label={(s as {label?: string}).label}
            bg={script.colors[i % script.colors.length]}
          />
        </Sequence>
      ))}
      <div
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          height: 14,
          width: `${progress}%`,
          background: '#fff',
        }}
      />
    </AbsoluteFill>
  );
};
