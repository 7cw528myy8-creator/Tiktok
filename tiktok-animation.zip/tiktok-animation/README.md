# TikTok-Animation mit Remotion

1. `npm install`
2. `npm run dev`   -> Vorschau im Browser
3. Texte in `src/script.ts` ändern
4. `npm run render` -> fertiges Video in `out/video.mp4` (1080x1920)
